import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import java.util.ArrayList;
import java.util.Random;

public class RandomChoiceController {

   ArrayList<String> choices = new ArrayList<>();

    @FXML
    private Button ChooseButton;

    @FXML
    private TextField choiceInput;

    @FXML
    private TextArea choicesArea;

    @FXML
    private AnchorPane darkBackground;

    @FXML
    private Text result;

    @FXML
    private Button teamButton1;
    
    @FXML
    private Button returnButton;

    @FXML
    private Button resetButton;
    
    @FXML
    void enterChoice(ActionEvent event) {
      String newChoice = choiceInput.getText();
      String currentList = choicesArea.getText();

      if(newChoice.trim().isEmpty())
      {
        choiceInput.setText("");
        return;
      }
      else 
      {
        choicesArea.setText(String.format(currentList + "%n%s", newChoice));
        choices.add(newChoice);
        choiceInput.setText("");
      }
    }
    
    @FXML
    void returnHome(ActionEvent event) throws IOException {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("AppHubFXML.fxml"));
      AnchorPane root = (AnchorPane)loader.load();
      Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
      Scene scene = new Scene(root);
      stage.setScene(scene);
    }
    
    @FXML
    void generateChoice(ActionEvent event) {
      int choicesLength = choices.size();

      if(choicesLength == 0)
      {
        result.setText("Enter Choices First");
      }
      else
      {
        String choice = choices.get(intGenerator(choicesLength));
        result.setText(choice);
      }
    }

    @FXML
    void reset(ActionEvent event) {
        ArrayList<String> empty = new ArrayList<>();
        choices = empty;
        
        choicesArea.setText("");
        result.setText("Resetting");

        setTimeout(() -> result.setText("Ready"), 1000);
    }

    public static int intGenerator(int upperbound)
    {
      Random random = new Random();
      int num = Math.abs(random.nextInt(upperbound));
      return num;
    }

    public void clearResult()
    {
      result.setText("");
    }

    public static void setTimeout(Runnable runnable, int delay)
    {
      new Thread(() -> {
          try 
          {
              Thread.sleep(delay);
              runnable.run();
          }
          catch (Exception e)
          {
              System.err.println(e);
          }
      }).start();
  }

}
