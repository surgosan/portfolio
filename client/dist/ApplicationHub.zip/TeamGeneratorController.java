import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;


public class TeamGeneratorController {

    ArrayList<String> players = new ArrayList<>();

    @FXML
    private Button ChooseButton;

    @FXML
    private AnchorPane darkBackground;

    @FXML
    private TextField playerInput;

    @FXML
    private TextArea playersArea;

    @FXML
    private Button resetButton;

    @FXML
    private Button returnButton;

    @FXML
    private Button teamButton1;

    @FXML
    private Label teamOne;

    @FXML
    private Label teamTwo;

    @FXML
    private Text vsText;

    @FXML
    void clearInput(MouseEvent event) {
        playerInput.setText("");
    }

    @FXML
    void enterPlayer(ActionEvent event) {
        String newPlayer = playerInput.getText();
        String currentPlayers = playersArea.getText();

        if(newPlayer.trim().isEmpty())
        {
            playerInput.setText("");
            return;
        }
        else 
        {
            players.add(newPlayer);
            playersArea.setText(String.format(currentPlayers + "%n%s", newPlayer));
            playerInput.setText("");
        }
    }

    @FXML
    void generateTeams(ActionEvent event) {
        int playersLength = players.size();

        if(playersLength == 0)
        {
            playersArea.setText("Enter Choices First");
        }
        else
        {
            teamOne.setVisible(true);
            teamTwo.setVisible(true);
            int playersHalfSize = players.size()/2;
            int updatedPlayersSize = playersLength;
            ArrayList<String> teamOnePlayers = new ArrayList<>();
            for(int i = 0; i < playersHalfSize; i++)
            {
                teamOnePlayers.add(players.remove(intGenerator(updatedPlayersSize)));  
                updatedPlayersSize--;  
            }
            teamOnePlayers.sort(Comparator.naturalOrder());
            players.sort(Comparator.naturalOrder());
            
            teamOne.setText(printArrayList(teamOnePlayers));
            vsText.setVisible(true);
            teamTwo.setText(printArrayList(players));
        }
    }

    @FXML
    void reset(ActionEvent event) {
        ArrayList<String> empty = new ArrayList<>();
        players = empty;
        
        playersArea.setText("");
        teamOne.setText("");
        teamTwo.setText("");
        playerInput.setText("Resetting");
        vsText.setVisible(false);


        setTimeout(() -> playerInput.setText("Ready"), 1000);
    }

    @FXML
    void returnHome(ActionEvent event) throws IOException{
        FXMLLoader loader = new FXMLLoader(getClass().getResource("AppHubFXML.fxml"));
        AnchorPane root = (AnchorPane)loader.load();
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
    }

    public static int intGenerator(int upperbound)
    {
      Random random = new Random();
      int num = Math.abs(random.nextInt(upperbound));
      return num;
    }

    public static void setTimeout(Runnable runnable, int delay)
    {
      new Thread(() -> {
          try 
          {
              Thread.sleep(delay);
              runnable.run();
          }
          catch (Exception e)
          {
              System.err.println(e);
          }
      }).start();
    }

    public static String printArrayList(ArrayList<String> list)
    {
        String output = "";
        
        for(int i = 0; i < list.size(); i++)
        {
            if(i == 0)
            {
                output = String.format("%s", list.get(i));
            }
            else
            {
                output = String.format("%s%n%s", output, list.get(i));
            }
        }
        return output;
    }

}
