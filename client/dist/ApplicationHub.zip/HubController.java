import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

public class HubController {

    @FXML
    private Button choiceButton;

    @FXML
    private AnchorPane darkBackground;

    @FXML
    private Button lamontButton;

    @FXML
    private Button teamButton;

    @FXML
    void buttonMouseDown(MouseEvent event) {
      
    }

    @FXML
    void choicePress(ActionEvent event) throws IOException {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("RandomChoiceFXML.fxml"));
      AnchorPane root = (AnchorPane)loader.load();
      Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
      Scene scene = new Scene(root);
      stage.setScene(scene);
    }

    @FXML
    void teamPress(ActionEvent event) throws IOException {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("TeamGenerationFXML.fxml"));
      AnchorPane root = (AnchorPane)loader.load();
      Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
      Scene scene = new Scene(root);
      stage.setScene(scene);
    }

    @FXML
    void lamontPress(ActionEvent event) throws IOException {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("LamontFXML.fxml"));
      AnchorPane root = (AnchorPane)loader.load();
      Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
      Scene scene = new Scene(root);
      stage.setScene(scene);
    }

}
