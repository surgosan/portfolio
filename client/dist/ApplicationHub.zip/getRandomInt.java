import java.util.Random;

public class getRandomInt {
    public static void main(String[] args) {
        System.out.println(intGenerator(50));
    }

    public static int intGenerator(int upperbound)
    {
      Random random = new Random();
      int num = Math.abs(random.nextInt(upperbound));
      return num;
    }
}
