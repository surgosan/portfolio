function login()
{
    if(document.getElementById("usernameText").value == 'babAdmin' && document.getElementById("passwordText").value == 'bab987')
    {
        window.close();
        window.open("AdminPage.html");
    }
}