
    
    const m1 = { lat: 0, lng: 0};
    const m2 = { lat: 30, lng: 0};
    var array1 = [{ lat: 0, lng: 30}, { lat: 30, lng: 30}];
// Initialize and add the map
function initMap() {

    var reader = new FileReader();
        var endResult;
        var CSVResult;

            function csvParse(csv) 
            {
                var lines = csv.split("\n");
                var infoMap = new Map();
                var infoArray = [];
                var result = new Map();
                var headers = lines[0].split(",");

                for(var i = 1; i < lines.length; i++)
                {
                    var currentline = lines[i].split(",");
                    for(var j = 0; j < headers.length; j++)
                    {
                        infoArray.push(currentline[j]);
                        result.set(i - 1 , infoArray);
                    }
                    infoArray = [];
                }
                //CSVResult = result,
                return result;
                //alert(this.result);
            }
            //companies = csvParse(data);
            //alert(companies);

//var client = new XMLHttpRequest();
//client.open('GET', 'DemoCSV.csv');
//client.onreadystatechange = function() {
  //alert(client.responseText);
  //CSVResult = client.responseText;
  //alert(CSVResult);
//}
//client.send();
//alert(CSVResult);


      //alert(CSVResult);
      //endResult = csvParse(CSVResult);
      //alert(endResult);
      

    /*var fileInput = document.getElementById('fileInput');
    fetch('DemoCSV.csv')
    .then(response => response.text())
    //.then(alert(data));
    .then((data) => {
        //data1 = data;
        csvParse(data);
        //CSVResult = data;
        alert(data);
        //  alert(data.get('Walgreens')[0]);
    })
    */
    



    // The location of USA
    const USA = { lat: 38, lng: -97 };
    // The map, centered at USA
    const map = new google.maps.Map(document.getElementById("map"), {
      zoom: 2,
      center: {lat: 15, lng: 0},
      streetViewControl: false,
      mapTypeControl: false,
    });
    // The marker, positioned at USA
    /*const marker = new google.maps.Marker({
      position: USA,
      map: map,
    });
    
    const marker22 = new google.maps.Marker({
        position: m1,
        map: map,
      });*/

    /*const script = document.createElement("script");
    script.src =
    "https://developers.google.com/maps/documentation/javascript/examples/json/earthquake_GeoJSONP.js";
  document.getElementsByTagName("head")[0].appendChild(script);*/

    
    /*const marker24 = new google.maps.Marker({
        position: m2,
        map: map,
      });*/
      function addMarkers(){
        for(var i = 0; i < CSVResult.size; i++){

            new google.maps.Marker({
                position: {lat: parseFloat(CSVResult.get(i)[3]), lng: parseFloat(CSVResult.get(i)[4])},
                map: map,
            })
        }
    }
    //addMarker();

    async function loadFileAndPrintToConsole(url) {
      try {
        const response = await fetch(url);
        const data = await response.text();
        //alert(data);
        //CSVResult = data;
        CSVResult = csvParse(data);
        //alert(data);
        //CSVResult = data;
        //alert(CSVResult);
        //alert(ParseString.data.get('Walgreens')[0]);
      } catch (err) {
        console.error(err);
      }
      //alert(CSVResult);
      //alert(CSVResult.get(0)[0]);
      //alert(CSVResult.get(2)[3]);
      //alert(CSVResult.get(11)[4]);
      addMarkers();
    }
    
    loadFileAndPrintToConsole('DemoCSV.csv');

    /*map.data.loadGeoJson(
      "MapJsonMine.json"
    );*/

    /*const eqfeed_callback = function (results) {
      for (let i = 0; i < results.features.length; i++) {
        const coords = results.features[i].geometry.coordinates;
        const latLng = new google.maps.LatLng(coords[1], coords[0]);
    
        new google.maps.Marker({
          position: latLng,
          map: map,
        });
      }
    };
    //eqfeed_callback();
    window.eqfeed_callback = eqfeed_callback;*/
    //})
  }


  
  window.initMap = initMap;

  /*var fileInput = document.getElementById('fileInput');
  fetch('DemoCSV.csv')
  .then(response => response.text())
  .then((data) => {
    //alert(data);
  })*/