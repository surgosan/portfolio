google.charts.load('current', {packages: ['corechart', 'line']});
google.charts.setOnLoadCallback(BunkaBikerActivity);

function BunkaBikerActivity() {

      var data = new google.visualization.DataTable();
      data.addColumn('number', 'X');
      data.addColumn('number', 'Page Visits');

      data.addRows([
        [0, 0,],   [1, 18,], [2, 24], [3, 56], [4, 89], [5, 83], [6, 99], [7, 121], [8, 101], [9, 163], [10, 202]
      ]);

      var options = {
        hAxis: {
          title: 'Time'
        },
        vAxis: {
          title: 'Page Visits'
        },
        colors: ['White'],
        backgroundColor: {
            'fill': 'black',
            'fillOpacity': 0.5 
          },
        curveType: 'function',
      };

      var chart = new google.visualization.LineChart(document.getElementById('BunkaBikerActivity'));

      chart.draw(data, options);
    }
