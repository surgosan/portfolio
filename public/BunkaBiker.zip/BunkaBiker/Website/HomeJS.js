function mapAlert()
{
    alert("Map is not available in this version.")
}