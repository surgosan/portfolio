//protect location of hosts
var map;
var numberofPins;

//protect host locations with location alteration
function getRandomNumber(min, max) 
{
    return Math.random() * (max - min) + min;
}

function numberOfPins(pins)
{
    return pins;
}

function initMap() {
    map = new google.maps.Map(document.getElementById("map"), 
    {
      zoom: 2,
      center: {lat: 15, lng: 0},
      streetViewControl: false,
      mapTypeControl: false,
    });

    CVSWork();
}

function addMarkers(CSV)
{
    pinVolume = CSV.size;
    document.getElementById("hostAmount").innerHTML = numberOfPins(pinVolume);
    for(var i = 0; i < CSV.size - 1; i++)
      {
//gathering pinInformation
        let pinName = CSV.get(i)[0];
        let pinType = CSV.get(i)[1];
        let pinDescription = CSV.get(i)[2];
        let mLat = parseFloat(CSV.get(i)[3]);
        let mLng = parseFloat(CSV.get(i)[4]);
        let latAndLng = { lat: 0, lng: 0};
        let location = CSV.get(i)[5];
        let pinLocation = CSV.get(i)[5];
        let pinAdress = CSV.get(i)[6];
//adding pin Logos
    let notAvailablePin = 'Photos/blackMotorcycleIcon.png';
    let noInfoPin = 'Photos/yellowMotoIcon.png';
    let outsidePin = 'Photos/redMotoIcon.png';
    let insidePin = 'Photos/blueMotoIcon.png';
    let outsideInsidePin = 'Photos/greenMotoIcon.png';
    let thisPin = 'Photos/yellowMotoIcon.png';

        if(pinType == "Not available")
        {
          thisPin = notAvailablePin;
        }
        else if(pinType == "Outdoor")
        {
          thisPin = outsidePin;
        }
        else if(pinType == "Indoor")
        {
          thisPin = insidePin;
        }
        else if(pinType == "Both")
        {
          thisPin = outsideInsidePin;
        }
        else{
          thisPin = thisPin;
        }

//infowindo layout
        let contentString = 
                '<div id="content" style="width: 300px;">' +
                '<h1>' + pinName + '</h1>' + 
                '<h2>' + 'Indoor/Outdoor: ' +  pinType + '</h2>' +
                '<h2>' + 'Location: ' + pinLocation + '</h2>' +
                '<p>' + '<b>Description:</b> ' + pinDescription + '</p>' +
                '</div>';
//end Gathering Pin Information
        
//addPins/circles from CSV
        function codeAddress() 
        {
          var geocoder = new google.maps.Geocoder();
          var address = pinAdress;
          geocoder.geocode({'address': address}, function(results, status) 
          {
            if (status == 'OK') 
            {
//alter circles to protect exact location
                var currentLat = results[0].geometry.location.lat();
                var currentLng = results[0].geometry.location.lng();
                var alteredLat =
                    currentLat + getRandomNumber(getRandomNumber(-.02,-.01), getRandomNumber(.02, .01));
                var alteredLng =
                    currentLng + getRandomNumber(getRandomNumber(-.02,-.01), getRandomNumber(.02, .01));
                var alteredLatLng = {lat: alteredLat, lng: alteredLng};

              let marker = new google.maps.Marker
              ({
                position: alteredLatLng,
                map: map,
                title: thisPin,
                icon: thisPin,
              })
              let newCirc = new google.maps.Circle({
                clickable: true,
                strokeColor: "#FFFFFF",
                strokeOpacity: 0.8,
                strokeWeight: 2,
                fillColor: "333333",
                fillOpacity: 0.05,
                center: alteredLatLng,
                radius: 2500,
                map: map
              });
              var infowindow = new google.maps.InfoWindow();
              function addInfoWindow(marker, message) 
              {
                var infoWindow = new google.maps.InfoWindow
                ({
                  content: message
                });
                google.maps.event.addListener(marker, 'click', function () 
                {
                  infoWindow.open(map, marker);
                });
                google.maps.event.addListener(newCirc, 'click', function(ev){
                    infoWindow.open(map, marker);
                });
                map.addListener("zoom_changed", () => {
                    if(map.getZoom() > 11)
                    {
                        marker.visible = false;
                    }
                  });
                map.addListener("zoom_changed", () => {
                    if(map.getZoom() < 11)
                    {
                        marker.visible = true;
                    }
                  });
              }
              addInfoWindow(marker, contentString);
              addInfoWindow(newCirc, contentString);
            } 
            else 
            {
              alert('Geocode' + address + 'was not successful for the following reason: ' + status);
            }});
        }
        codeAddress();
    }
}


function CVSWork()
{
    var CSVResult;

    function csvParse(csv) 
    {
      var lines = csv.split("\n");
      var infoArray = [];
      var result = new Map();
      var headers = lines[0].split(",");

      for(var i = 1; i < lines.length; i++)
      {
          var currentline = lines[i].split(",");
          for(var j = 0; j < headers.length; j++)
          {
              infoArray.push(currentline[j]);
              result.set(i - 1 , infoArray);
          }
          infoArray = [];
      }
      return result;
    }

    async function loadFileAndPrintToConsole(url) 
    {
        try 
        {
        const response = await fetch(url);
        const data = await response.text();

        CSVResult = csvParse(data);
        } catch (err) 
        {
        console.error(err);
        }
        addMarkers(CSVResult);
    }
  loadFileAndPrintToConsole('Pins - Copy.csv');
}