let x = 'he';
function getEmail()
{
    return document.getElementById("email").value;
}
function getName()
{
    return document.getElementById("firstName").value;
}

function copyTextOver()
{   
    var x = document.getElementById("userComment").value;
    document.getElementById("newMessage").value = x;
    document.getElementById("mLabel").style.display = "inline";
}

function txtAreaFocus()
{
    document.getElementById("userComment").focus();
}
function sumbitForm(){
   emailjs.send("service_dqpaua8","template_lx8qws8",{
    from_name: document.getElementById("firstName").value,
    email_id: document.getElementById("email").value,
    message: document.getElementById("newMessage").value,
    });
    window.close();
    window.open("ContactVerification.html");
}
export {getEmail, getName};