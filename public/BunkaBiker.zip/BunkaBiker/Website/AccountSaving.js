var txtFile = "AccountTest.txt";
var file = new File(txtFile);

file.open("r");
var str;
while(!file.eof)
{
    str += file.readln() + "\n";
}
file.close();
alert(str);
