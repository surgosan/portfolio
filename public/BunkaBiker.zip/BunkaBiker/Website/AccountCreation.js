function checkPasswords()
{
    let firstPass = document.getElementById("password").value;
    let retype = document.getElementById("retype").value;
    if(firstPass !== retype)
    {
        document.getElementById("retypeP").style.display = "block";
    }
    else
    {
        document.getElementById("retypeP").style.display = "none";
    }
}

var previousUsernameInput;
function copyUserEmail(){
    if(document.getElementById("usernameEmail").checked)
    {
        previousUsernameInput = document.getElementById("username").value;
        let email = document.getElementById("emailInput").value;
        document.getElementById("username").value = email;
    }
    else
    {
        document.getElementById("username").value = previousUsernameInput;
    }
}

function showH()
{
    document.getElementById("hostContent").style.display = "initial";
}
function hideH()
{
    document.getElementById("hostContent").style.display = "none";
}
function geocode()
{
    var geocoder = new google.maps.Geocoder();
    var address = document.getElementById("adress").value;
    geocoder.geocode({'address': address}, function(results, status) 
          {
            if (status == 'OK') 
            {
                document.getElementById("valid").style.display = "none";
                document.getElementById("notValid").style.display = "inline-block";
            }
            else 
            {
                document.getElementById("valid").style.display = "inline-block";
                document.getElementById("notValid").style.display = "none";
            }});    
}
function showHideAvailNotice()
{
    var checkboxes = document.getElementsByName("availability");
    var result = 0;
    for (var i = 0; i < checkboxes.length; i++)
    {
        if(checkboxes[i].checked)
        {
            result++;
        }
    }
    if(result == 0)
    {
        document.getElementById("availTimesNotice").style.display = "initial";
    }
}
function showHideDay1()
{
    if(document.getElementById("AvOne").checked)
    {
        document.getElementById("SundayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("SundayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay2()
{
    if(document.getElementById("AvTwo").checked)
    {
        document.getElementById("MondayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("MondayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay3()
{
    if(document.getElementById("AvThree").checked)
    {
        document.getElementById("TuesdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("TuesdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay4()
{
    if(document.getElementById("AvFour").checked)
    {
        document.getElementById("WednesdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("WednesdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay5()
{
    if(document.getElementById("AvFive").checked)
    {
        document.getElementById("ThursdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("ThursdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay6()
{
    if(document.getElementById("AvSix").checked)
    {
        document.getElementById("FridayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("FridayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay7()
{
    if(document.getElementById("AvSeven").checked)
    {
        document.getElementById("SaturdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("SaturdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideEveryDayTime()
{
    var checkboxes = document.getElementsByName("availability");
    var numberChecked = 0;
    for (var i = 0; i < checkboxes.length; i++)
    {
        if(checkboxes[i].checked)
        {
            numberChecked++;
        }
    }
    if(numberChecked >= 2)
    {
        document.getElementById("copyTimes").style.display = "block";
    }
    else
    {
        document.getElementById("copyTimes").style.display = "none";
    }
}
function checkRestDays()
{
    if(document.getElementById("AvEight").checked)
    {
        var checkboxes = document.getElementsByName("availability");
        for (var i = 0; i < checkboxes.length; i++)
        {
            checkboxes[i].checked = true;
        }   
        showHideDay1();
        showHideDay2();
        showHideDay3();
        showHideDay4();
        showHideDay5();
        showHideDay6();
        showHideDay7();
    }
    else
    {
        var checkboxes = document.getElementsByName("availability");
        for (var i = 0; i < checkboxes.length; i++)
        {
            checkboxes[i].checked = false;
        }
        showHideDay1();
        showHideDay2();
        showHideDay3();
        showHideDay4();
        showHideDay5();
        showHideDay6();
        showHideDay7();
    }
}
function showHideCopyTime()
{
    if(document.getElementById("anyDayCheck").checked)
    {
        document.getElementById("copyTimeTime").style.display = "block";
    }
    else
    {
        document.getElementById("copyTimeTime").style.display = "none";
    }
}
function copyOverTimes()
{
    let startTime = document.getElementById("allStart").value;
    let endTime = document.getElementById("allEnd").value;

        document.getElementById("SundayStart").value = startTime;
        document.getElementById("SundayEnd").value = endTime;

        document.getElementById("MondayStart").value = startTime;
        document.getElementById("MondayEnd").value = endTime;

        document.getElementById("TuesdayStart").value = startTime;
        document.getElementById("TuesdayEnd").value = endTime;

        document.getElementById("WednesdayStart").value = startTime;
        document.getElementById("WednesdayEnd").value = endTime;

        document.getElementById("ThursdayStart").value = startTime;
        document.getElementById("ThursdayEnd").value = endTime;

        document.getElementById("FridayStart").value = startTime;
        document.getElementById("FridayEnd").value = endTime;

        document.getElementById("SaturdayStart").value = startTime;
        document.getElementById("SaturdayEnd").value = endTime;
}
function showPetBox()
{
    document.getElementById("petsTrue").style.display = "block";
}
function hidePetBox()
{
    document.getElementById("petsTrue").style.display = "none";
}
function copyDescriptionResponse()
{
    var response = document.getElementById("descriptionTextArea").value;
    document.getElementById("hostDesc").value = response;
}
function checkInClick()
{
    if(document.getElementById("in").checked)
    {
        document.getElementById('checkInOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('checkInOption').style.display = "none";
    }
}
function checkOutClick()
{
    if(document.getElementById("out").checked)
    {
        document.getElementById('checkOutOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('checkOutOption').style.display = "none";
    }
}
function maxGuestClick()
{
    if(document.getElementById("maxGuest").checked)
    {
        document.getElementById('maxGuestsOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('maxGuestsOption').style.display = "none";
    }
}
function smokeClick()
{
    if(document.getElementById("smoke").checked)
    {
        document.getElementById('smokingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('smokingOption').style.display = "none";
    }
}
function drinkClick()
{
    if(document.getElementById("drink").checked)
    {
        document.getElementById('drinkingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('drinkingOption').style.display = "none";
    }
}
function drugsClick()
{
    if(document.getElementById("drugs").checked)
    {
        document.getElementById('drugOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('drugOption').style.display = "none";
    }
}
function weaponsClick()
{
    if(document.getElementById("weapons").checked)
    {
        document.getElementById('weaponOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('weaponOption').style.display = "none";
    }
}
function bedTimeClick()
{
    if(document.getElementById("bedTime").checked)
    {
        document.getElementById('bedTimeOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('bedTimeOption').style.display = "none";
    }
}
function wakeClick()
{
    if(document.getElementById("wake").checked)
    {
        document.getElementById('wakeUpOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('wakeUpOption').style.display = "none";
    }
}
function beddingClick()
{
    if(document.getElementById("bedding").checked)
    {
        document.getElementById('beddingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('beddingOption').style.display = "none";
    }
}
function feedingClick()
{
    if(document.getElementById("feeding").checked)
    {
        document.getElementById('feedingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('feedingOption').style.display = "none";
    }
}
function petsClick()
{
    if(document.getElementById("pets").checked)
    {
        document.getElementById('petPolicyOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('petPolicyOption').style.display = "none";
    }
}
function petYesClick()
{

    document.getElementById("petNoOption").style.display = "none";
}
function petNoClick()
{   
    document.getElementById("petNoOption").style.display = "block";
}


function picYesClick()
{

    document.getElementById("reqPicMore").style.display = "block";
}
function picNoClick()
{   
    document.getElementById("reqPicMore").style.display = "none";
}


function docuYesClick()
{

    document.getElementById("reqDocuMore").style.display = "block";
}
function docuNoClick()
{   
    document.getElementById("reqDocuMore").style.display = "none";
}


function ridersClick()
{
    if(document.getElementById("riders").checked)
    {
        document.getElementById('specificRidersOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('specificRidersOption').style.display = "none";
    }
}
function picturesClick()
{
    if(document.getElementById("pictures").checked)
    {
        document.getElementById('requirePicturesOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('requirePicturesOption').style.display = "none";
    }
}
function docuClick()
{
    if(document.getElementById("documentation").checked)
    {
        document.getElementById('reqDocuOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('reqDocuOption').style.display = "none";
    }
}
function meetClick()
{
    if(document.getElementById("meet").checked)
    {
        document.getElementById('sepMeetOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('sepMeetOption').style.display = "none";
    }
}
function fourClick()
{
    if(document.getElementById("fourWheel").checked)
    {
        document.getElementById('allowFoursOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('allowFoursOption').style.display = "none";
    }
}

function checkRadio(radio_name)
{
    var oRadio = document.forms[0].elements[radio_name];
    for(var i = 0; i < oRadio.length; i++)
   {
      if(oRadio[i].checked)
      {
         return true;
      }
   }
   return false;
}
 function getRadioCheckedValue(radio_name)
{
   var oRadio = document.forms[0].elements[radio_name];

   for(var i = 0; i < oRadio.length; i++)
   {
      if(oRadio[i].checked)
      {
         return oRadio[i].value;
      }
   }

   return '';
}
function getCheckValue(checkName)
{
    var checkbox_val = checkName.value;
    if (checkName.checked == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}
function getMutiChecks(checkName) 
{//returns 1 or 0 digits for true false
    var checkboxes = document.getElementsByName(checkName);
    var result = null;
    for (var i = 0; i < checkboxes.length; i++) {
        if(result == null)
        {
            if(checkboxes[i].checked)
            {
                result = "1";
            }
            else
            {
                result = "0";
            }
        }
        else
        {
            if(checkboxes[i].checked)
            {
                result += "1";
            }
            else
            {
                result += "0";
            }
        }
    }
    return result;
}
//TODO: add more
//TODO: remove photo

//try to remove var in this function
var emptyImages = [0,1,2,3,4,5,6,7];

var loadImage = function(event)
{//check if images is empty, if not then execute
    let sourceFiles = [];
    for(let i = 0; i < event.target.files.length; i++)
        {
            //var fileSource = URL.createObjectURL(event.target.files[i]);
            sourceFiles.push(URL.createObjectURL(event.target.files[i]));
        }
        for(let j = 0; j < sourceFiles.length; j++)
        {
                document.getElementById("imgPreview" + emptyImages[0]).src = sourceFiles[j];
                document.getElementById("imgPreview" + emptyImages[0]).style.display = "initial";
                emptyImages.shift();
        }

    if(emptyImages.length == 0)
    {
        document.getElementById("picLabel").style.display = "none";
    }
}
function removeImage(index)
{
    var i = index - 1;
    let img = "imgPreview" + [i];
    document.getElementById("imgPreview" + i).src = "null";
    document.getElementById("imgPreview" + i).style.display = "none";
    emptyImages.push(i);
    emptyImages.sort();
    document.getElementById("picLabel").style.display = "initial";
}


function submitForm()
{
//general Questions
    var firstName = document.getElementById("firstName").value;
    var middleName = document.getElementById("middleName").value;
    var lastName = document.getElementById("lastName").value;
    var gender = getRadioCheckedValue("genderOptions");
    var Birthday = document.getElementById("birthday").value;
    var location = getRadioCheckedValue("location");
    var email = document.getElementById("emailInput").value;
    var phoneNumber = document.getElementById("phone").value;
    var userName = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    alert(firstName + middleName + lastName + gender + Birthday + location + email + phoneNumber + userName + password)
}