function geocode()
{
    var geocoder = new google.maps.Geocoder();
    var address = document.getElementById("adress").value;
    geocoder.geocode({'address': address}, function(results, status) 
          {
            if (status == 'OK') 
            {
                document.getElementById("valid").style.display = "none";
                document.getElementById("notValid").style.display = "inline-block";
            }
            else 
            {
                document.getElementById("valid").style.display = "inline-block";
                document.getElementById("notValid").style.display = "none";
            }});    
}
function showHideAvailNotice()
{
    var checkboxes = document.getElementsByName("availability");
    var result = 0;
    for (var i = 0; i < checkboxes.length; i++)
    {
        if(checkboxes[i].checked)
        {
            result++;
        }
    }
    if(result == 0)
    {
        document.getElementById("availTimesNotice").style.display = "initial";
    }
}
function showHideDay1()
{
    if(document.getElementById("AvOne").checked)
    {
        document.getElementById("SundayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("SundayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay2()
{
    if(document.getElementById("AvTwo").checked)
    {
        document.getElementById("MondayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("MondayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay3()
{
    if(document.getElementById("AvThree").checked)
    {
        document.getElementById("TuesdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("TuesdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay4()
{
    if(document.getElementById("AvFour").checked)
    {
        document.getElementById("WednesdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("WednesdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay5()
{
    if(document.getElementById("AvFive").checked)
    {
        document.getElementById("ThursdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("ThursdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay6()
{
    if(document.getElementById("AvSix").checked)
    {
        document.getElementById("FridayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("FridayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideDay7()
{
    if(document.getElementById("AvSeven").checked)
    {
        document.getElementById("SaturdayTime").style.display = "block";
        document.getElementById("availTimesNotice").style.display = "none";
    }
    else
    {
        document.getElementById("SaturdayTime").style.display = "none";
        document.getElementById("AvEight").checked = false;
    }
    showHideAvailNotice();
}
function showHideEveryDayTime()
{
    var checkboxes = document.getElementsByName("availability");
    var numberChecked = 0;
    for (var i = 0; i < checkboxes.length; i++)
    {
        if(checkboxes[i].checked)
        {
            numberChecked++;
        }
    }
    if(numberChecked >= 2)
    {
        document.getElementById("copyTimes").style.display = "block";
    }
    else
    {
        document.getElementById("copyTimes").style.display = "none";
    }
}
function checkRestDays()
{
    if(document.getElementById("AvEight").checked)
    {
        var checkboxes = document.getElementsByName("availability");
        for (var i = 0; i < checkboxes.length; i++)
        {
            checkboxes[i].checked = true;
        }   
        showHideDay1();
        showHideDay2();
        showHideDay3();
        showHideDay4();
        showHideDay5();
        showHideDay6();
        showHideDay7();
    }
    else
    {
        var checkboxes = document.getElementsByName("availability");
        for (var i = 0; i < checkboxes.length; i++)
        {
            checkboxes[i].checked = false;
        }
        showHideDay1();
        showHideDay2();
        showHideDay3();
        showHideDay4();
        showHideDay5();
        showHideDay6();
        showHideDay7();
    }
}
function showHideCopyTime()
{
    if(document.getElementById("anyDayCheck").checked)
    {
        document.getElementById("copyTimeTime").style.display = "block";
    }
    else
    {
        document.getElementById("copyTimeTime").style.display = "none";
    }
}
function copyOverTimes()
{
    let startTime = document.getElementById("allStart").value;
    let endTime = document.getElementById("allEnd").value;

        document.getElementById("SundayStart").value = startTime;
        document.getElementById("SundayEnd").value = endTime;

        document.getElementById("MondayStart").value = startTime;
        document.getElementById("MondayEnd").value = endTime;

        document.getElementById("TuesdayStart").value = startTime;
        document.getElementById("TuesdayEnd").value = endTime;

        document.getElementById("WednesdayStart").value = startTime;
        document.getElementById("WednesdayEnd").value = endTime;

        document.getElementById("ThursdayStart").value = startTime;
        document.getElementById("ThursdayEnd").value = endTime;

        document.getElementById("FridayStart").value = startTime;
        document.getElementById("FridayEnd").value = endTime;

        document.getElementById("SaturdayStart").value = startTime;
        document.getElementById("SaturdayEnd").value = endTime;
}
function showPetBox()
{
    document.getElementById("petsTrue").style.display = "block";
}
function hidePetBox()
{
    document.getElementById("petsTrue").style.display = "none";
}
function copyDescriptionResponse()
{
    var response = document.getElementById("descriptionTextArea").value;
    document.getElementById("hostDesc").value = response;
}
function checkInClick()
{
    if(document.getElementById("in").checked)
    {
        document.getElementById('checkInOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('checkInOption').style.display = "none";
    }
}
function checkOutClick()
{
    if(document.getElementById("out").checked)
    {
        document.getElementById('checkOutOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('checkOutOption').style.display = "none";
    }
}
function maxGuestClick()
{
    if(document.getElementById("maxGuest").checked)
    {
        document.getElementById('maxGuestsOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('maxGuestsOption').style.display = "none";
    }
}
function smokeClick()
{
    if(document.getElementById("smoke").checked)
    {
        document.getElementById('smokingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('smokingOption').style.display = "none";
    }
}
function drinkClick()
{
    if(document.getElementById("drink").checked)
    {
        document.getElementById('drinkingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('drinkingOption').style.display = "none";
    }
}
function drugsClick()
{
    if(document.getElementById("drugs").checked)
    {
        document.getElementById('drugOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('drugOption').style.display = "none";
    }
}
function weaponsClick()
{
    if(document.getElementById("weapons").checked)
    {
        document.getElementById('weaponOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('weaponOption').style.display = "none";
    }
}
function bedTimeClick()
{
    if(document.getElementById("bedTime").checked)
    {
        document.getElementById('bedTimeOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('bedTimeOption').style.display = "none";
    }
}
function wakeClick()
{
    if(document.getElementById("wake").checked)
    {
        document.getElementById('wakeUpOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('wakeUpOption').style.display = "none";
    }
}
function beddingClick()
{
    if(document.getElementById("bedding").checked)
    {
        document.getElementById('beddingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('beddingOption').style.display = "none";
    }
}
function feedingClick()
{
    if(document.getElementById("feeding").checked)
    {
        document.getElementById('feedingOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('feedingOption').style.display = "none";
    }
}
function petsClick()
{
    if(document.getElementById("pets").checked)
    {
        document.getElementById('petPolicyOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('petPolicyOption').style.display = "none";
    }
}
function petYesClick()
{

    document.getElementById("petNoOption").style.display = "none";
}
function petNoClick()
{   
    document.getElementById("petNoOption").style.display = "block";
}


function picYesClick()
{

    document.getElementById("reqPicMore").style.display = "block";
}
function picNoClick()
{   
    document.getElementById("reqPicMore").style.display = "none";
}


function docuYesClick()
{

    document.getElementById("reqDocuMore").style.display = "block";
}
function docuNoClick()
{   
    document.getElementById("reqDocuMore").style.display = "none";
}


function ridersClick()
{
    if(document.getElementById("riders").checked)
    {
        document.getElementById('specificRidersOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('specificRidersOption').style.display = "none";
    }
}
function picturesClick()
{
    if(document.getElementById("pictures").checked)
    {
        document.getElementById('requirePicturesOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('requirePicturesOption').style.display = "none";
    }
}
function docuClick()
{
    if(document.getElementById("documentation").checked)
    {
        document.getElementById('reqDocuOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('reqDocuOption').style.display = "none";
    }
}
function meetClick()
{
    if(document.getElementById("meet").checked)
    {
        document.getElementById('sepMeetOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('sepMeetOption').style.display = "none";
    }
}
function fourClick()
{
    if(document.getElementById("fourWheel").checked)
    {
        document.getElementById('allowFoursOption').style.display = "block";
        document.getElementById('extraOptions').style.display = "block";
    }
    else
    {
        document.getElementById('allowFoursOption').style.display = "none";
    }
}

function checkRadio(radio_name)
{
    var oRadio = document.forms[0].elements[radio_name];
    for(var i = 0; i < oRadio.length; i++)
   {
      if(oRadio[i].checked)
      {
         return true;
      }
   }
   return false;
}
 function getRadioCheckedValue(radio_name)
{
   var oRadio = document.forms[0].elements[radio_name];

   for(var i = 0; i < oRadio.length; i++)
   {
      if(oRadio[i].checked)
      {
         return oRadio[i].value;
      }
   }

   return '';
}
function getCheckValue(checkName)
{
    var checkbox_val = checkName.value;
    if (checkName.checked == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}
function getMutiChecks(checkName) 
{//returns 1 or 0 digits for true false
    var checkboxes = document.getElementsByName(checkName);
    var result = null;
    for (var i = 0; i < checkboxes.length; i++) {
        if(result == null)
        {
            if(checkboxes[i].checked)
            {
                result = "1";
            }
            else
            {
                result = "0";
            }
        }
        else
        {
            if(checkboxes[i].checked)
            {
                result += "1";
            }
            else
            {
                result += "0";
            }
        }
    }
    return result;
}
//TODO: add more
//TODO: remove photo

//try to remove var in this function
var emptyImages = [0,1,2,3,4,5,6,7];

var loadImage = function(event)
{//check if images is empty, if not then execute
    let sourceFiles = [];
    for(let i = 0; i < event.target.files.length; i++)
        {
            //var fileSource = URL.createObjectURL(event.target.files[i]);
            sourceFiles.push(URL.createObjectURL(event.target.files[i]));
        }
        for(let j = 0; j < sourceFiles.length; j++)
        {
                document.getElementById("imgPreview" + emptyImages[0]).src = sourceFiles[j];
                document.getElementById("imgPreview" + emptyImages[0]).style.display = "initial";
                emptyImages.shift();
        }

    if(emptyImages.length == 0)
    {
        document.getElementById("picLabel").style.display = "none";
    }
}
function removeImage(index)
{
    var i = index - 1;
    let img = "imgPreview" + [i];
    document.getElementById("imgPreview" + i).src = "null";
    document.getElementById("imgPreview" + i).style.display = "none";
    emptyImages.push(i);
    emptyImages.sort();
    document.getElementById("picLabel").style.display = "initial";
}

function submitForm()
{
    var address = null;
    var accomodation = null;
    var availability = null;
    var sundayIn = null;
    var sundayOut = null;
    var mondayIn = null;
    var mondayOut = null;
    var tuesdayIn = null;
    var tuesdayOut = null;
    var wednesdayIn = null;
    var wednesdayOut = null;
    var thursdayIn = null;
    var thursdayOut = null;
    var fridayIn = null;
    var fridayOut = null;
    var saturdayIn = null;
    var saturdayOut = null;
    var parking = null;
    var ownPets = null;
    var ownPetsType = null;
    var ownPetsLocation = null;
    var description = null;
    var photos = null;
    var checkIn = null;
    var checkOut = null;
    var maxGuests = null;
    var smoking = null;
    var drinking = null;
    var drugs = null;
    var weapons = null;
    var bedTime = null;
    var wakeUp = null;
    var bedding = null;
    var feeding = null;
    var allowPets = null;
    var deniedPets = null;
    var specificRiders = null;
    var requirePictures = null;
    var requestedPictures = null;
    var requireDocuments = null;
    var requestedDocuments = null;
    var seperateMeet = null;
    var allowTowing = null;
//fill in address value
    if(document.getElementById("adress").value != null)
    {
        address = document.getElementById("adress").value;
    }
//fill in accomodation
    if(getRadioCheckedValue("accomodation") != null)
    {
        accomodation = getRadioCheckedValue("accomodation");
    }
        //alert(accomodation);
    if(getMutiChecks("availability") != null)
    {
        availability = getMutiChecks("availability");
    }
        //alert(availability);
    if(document.getElementById("SundayStart").value != null)
    {
        sundayIn = document.getElementById("SundayStart").value;
    }
        //alert(sundayIn);
    if(document.getElementById("SundayEnd").value != null)
    {
        sundayOut = document.getElementById("SundayEnd").value;
    }
        //alert(sundayOut);
    
    if(document.getElementById("MondayStart").value != null)
    {
        mondayIn = document.getElementById("MondayStart").value;
    }
        //alert(mondayIn);
    if(document.getElementById("MondayEnd").value != null)
    {
        mondayOut = document.getElementById("MondayEnd").value;
    }
        //alert(mondayOut);
    if(document.getElementById("TuesdayStart").value != null)
    {
        tuesdayIn = document.getElementById("TuesdayStart").value;
    }
        //alert(tuesdayIn);
    if(document.getElementById("TuesdayEnd").value != null)
    {
        tuesdayOut = document.getElementById("TuesdayEnd").value;
    }
        //alert(tuesdayOut);
    if(document.getElementById("WednesdayStart").value != null)
    {
        wednesdayIn = document.getElementById("WednesdayStart").value;
    }
        //alert(wednesdayIn);
    if(document.getElementById("WednesdayEnd").value != null)
    {
        wednesdayOut = document.getElementById("WednesdayEnd").value;
    }
        //alert(wednesdayOut);
    if(document.getElementById("ThursdayStart").value != null)
    {
        thursdayIn = document.getElementById("ThursdayStart").value;
    }
        //alert(thursdayIn);
    if(document.getElementById("ThursdayEnd").value != null)
    {
        thursdayOut = document.getElementById("ThursdayEnd").value;
    }
        //alert(thursdayOut);
    if(document.getElementById("FridayStart").value != null)
    {
        fridayIn = document.getElementById("FridayStart").value;
    }
        //alert(fridayIn);
    if(document.getElementById("FridayEnd").value != null)
    {
        fridayOut = document.getElementById("FridayEnd").value;
    }
        //alert(fridayOut)
    if(document.getElementById("SaturdayStart").value != null)
    {
        saturdayIn = document.getElementById("SaturdayStart").value;
    }
        //alert(saturdayIn);
    if(document.getElementById("SaturdayEnd").value != null)
    {
        saturdayOut = document.getElementById("SaturdayEnd").value;
    }
    if(checkRadio("parking"))
    {
        parking = getRadioCheckedValue("parking");
    }
    if(checkRadio("pets"))
    {
        ownPets = getRadioCheckedValue("pets");
        ownPetsType = document.getElementById("petType").value
        if(checkRadio("petLocation"))
        {
            ownPetsLocation = getRadioCheckedValue("petLocation");
        }
    }
    if(document.getElementById("petType").value != null)
    {
        ownPetsType = document.getElementById("petType").value;
    }
    if(document.getElementById("hostDesc").value != null)   //make sure it copies from text area
    {
        description = document.getElementById("hostDesc").value;
    }
    if(document.getElementById("checkIn").value != null)
    {
        checkIn = document.getElementById("checkIn").value;
    }
    if(document.getElementById("checkOut").value != null)
    {
        checkOut = document.getElementById("checkOut").value;
    }
    maxGuests = document.getElementById("maxGuests").value;
    if(checkRadio("smoking"))
    {
        smoking = getRadioCheckedValue("smoking");
    }
    if(checkRadio("drinking"))
    {
        drinking = getRadioCheckedValue("drinking");
    }
    if(checkRadio("drug"))
    {
        drugs = getRadioCheckedValue("drug");
    }
    if(checkRadio("weapon"))
    {
        weapons = getRadioCheckedValue("weapon");
    }
    if(document.getElementById("bedTimeTime").value != null)
    {
        bedTime = document.getElementById("bedTimeTime").value;
    }
    if(document.getElementById("wakeUp").value != null)
    {
        wakeUp = document.getElementById("wakeUp").value;
    }
    if(checkRadio("beddingRadio"))
    {
        bedding = getRadioCheckedValue("beddingRadio");
    }
    if(checkRadio("feedingRadio"))
    {
        feeding = getRadioCheckedValue("feedingRadio");
    }
    if(checkRadio("petPolicy"))
    {
        allowPets = getRadioCheckedValue("petPolicy");
    }
    if(document.getElementById("petNoText").value != null)
    {
        deniedPets = document.getElementById("petNoText").value;
    }
    if(document.getElementById("specificRiders").value != null)
    {
        specificRiders = document.getElementById("specificRiders").value;
    }
    if(checkRadio("reqPic"))
    {
        requirePictures = getRadioCheckedValue("reqPic");
    }
    if(checkRadio("reqPictureY"))
    {
        requestedPictures = getMutiChecks("reqPictureY");
    }
    if(checkRadio("reqDocu"))
    {
        requireDocuments = getRadioCheckedValue("reqDocu");
    }
    if(checkRadio("reqDocuY"))
    {
        requestedDocuments =  getMutiChecks("reqDocuY");
    }
    if(document.getElementById("meetingLocation").value != null)
    {
        seperateMeet = document.getElementById("meetingLocation").value;
    }
    if(checkRadio("allowFours"))
    {
        allowTowing = getRadioCheckedValue("allowFours");
    }
    if(document.getElementById("imgPreview0").src != null)
    {
        photos = document.getElementById("imgPreview0").src;
    }
    alert(address + '' + accomodation + '' + availability + '' + sundayIn + '' + sundayOut + '' + mondayIn + '' + mondayOut + '' + tuesdayIn + '' + 
    tuesdayOut + '' + wednesdayIn + '' +  wednesdayOut + '' + thursdayIn + '' + thursdayOut + '' + fridayIn + '' + fridayOut
    + '' + saturdayIn + '' + saturdayOut + '' + parking + '' + ownPets + '' + ownPetsLocation + '' + ownPetsType+ ''+ description + '' + photos + '' + 
    checkIn + '' + checkOut + '' + maxGuests + '' + smoking + '' + drinking + '' + drugs + '' + weapons + '' + bedTime + '' + wakeUp + '' + 
    bedding + '' + feeding + '' + allowPets + '' + deniedPets + '' + specificRiders + '' + requestedPictures + '' + requestedPictures + '' + 
    requireDocuments + '' + requestedDocuments + '' + seperateMeet + '' + allowTowing)
}