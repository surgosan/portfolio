import {getEmail, getName} from './Contact.js';
alert(getEmail);
window.onload = function()
{
    let name = getName();
    let email = getEmail();
    document.getElementById("thanks").innerHTML = name;
    document.getElementById("email").innerHTML = email;
}
