google.charts.load('current', {packages: ['corechart', 'line']});
google.charts.setOnLoadCallback(BunkaBikerActivity);
google.charts.load("current", {packages:["corechart"]});
google.charts.setOnLoadCallback(BudgetPie);
function BunkaBikerActivity() {
      var data = new google.visualization.DataTable();
      data.addColumn('date', 'X');
      data.addColumn('number', 'Page Visits');

      data.addRows([
        [new Date(2022, 11), 0,], [new Date(2023, 2), 18,], [new Date(2023, 3), 24], [new Date(2023, 4), 56],
           [new Date(2023, 5), 89], [new Date(2023, 6), 83], [new Date(2023, 7), 99], [new Date(2023, 8), 121],
            [new Date(2023, 9), 101], [new Date(2023, 10), 163], [new Date(2023, 11), 202],
      ]);

      var options = {
        hAxis: {
          title: 'Month',
          textStyle: {
            color: 'white',
            fontSize: 16,
          },
          titleTextStyle: {
            color: 'white',
            fontSize: 16,
          }
        },
        vAxis: {
          title: 'Page Visits',
          textStyle: {
            color: 'white',
            fontSize: 10,
          },
          titleTextStyle: {
            color: 'white',
            fontSize: 16,
          }
        },
        colors: ['White'],
        backgroundColor: {
            'fill': 'black',
            'fillOpacity': 0.1 
          },
        curveType: 'function',
          width: document.getElementById('BunkaBikerActivity').offsetWidth,
          height: document.getElementById('BunkaBikerActivity').offsetHeight,
      };

      var chart = new google.visualization.LineChart(document.getElementById('BunkaBikerActivity'));

      chart.draw(data, options);
    }

var income = 600;
var expense = 400;
function BudgetPie() 
{
  var data = google.visualization.arrayToDataTable([
    ['Money', 'Net'],
    ['Income', income],
    ['Expense', expense],
  ]);

  var options = {
    title: 'Net Expense',
    titleTextStyle: {color: 'White', fontSize: 16, bold: true,},
    legend: {position: 'right', textStyle: {color: 'white', fontSize: 16}},
    colors: ['#F71708', "#08E8F7"],
    pieHole: .5,
    pieSliceTextStyle: 
      {
        color: 'White',
        fontSize: 10,
      },
    backgroundColor: 
      {
        'fill': 'black',
        'fillOpacity': 0.1 
      },
    pieSliceText: 'label',
    slices: {0: {offset: 0.1}, 1: {offset: 0.1}},
    width: document.getElementById('budgetPie').offsetWidth,
    height: document.getElementById('budgetPie').offsetHeight,
  };

  var PieChart = new google.visualization.PieChart(document.getElementById('budgetPie'));
  PieChart.draw(data, options);
}

function customBudget()
{
  if(document.getElementById("incomeInput").value > 0 && document.getElementById("expensesInput").value > 0)
  {
    income = document.getElementById("incomeInput").value;
    expense = document.getElementById("expensesInput").value;
    BudgetPie();
  }
  else
  {
    alert("Check your income and expense inputs");
  }
}

//update size of activity chart on window resize
window.onresize = function(event) {
  BunkaBikerActivity();
  BudgetPie();
};